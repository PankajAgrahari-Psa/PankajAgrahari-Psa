# Day-29-SQLBolt_Tasks
All the 18 lessons (containing exercises) of the SQL-Bolt are completed.  
The 18 exercises (in 18 lessons) are completed, and the screenshots are inside the respective folders named "xy_SQL_Bolt_Lesson_xy" or "xy_SQLBolt_Lesson_xy".   
Kindly open the folders to check the screenshots.  
